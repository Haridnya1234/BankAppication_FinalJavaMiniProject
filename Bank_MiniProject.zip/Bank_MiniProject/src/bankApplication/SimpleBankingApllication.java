package bankApplication;

import java.util.InputMismatchException;
import java.util.Scanner;
public class SimpleBankingApllication extends DepositWithdraw
{
	static Scanner sc=new Scanner(System.in);
	static String username;
	static int passcode;
	//675456324132l this account number is common for every statement

	static void choice() throws Exception
	{
		System.out.println("**************Welcome To Bank Of Maharashtra**************");
		//*****************************************This Section is for App Open****************************************
		//In our mobile we need to login for that application that we have downloaded
		System.out.println("Enter your Username:- ");
		username=sc.next();
		pin();
		
	//	CreateAccount.pin();                              //This method is for pin validation from CreateAccount class
		System.out.println("--------------------------------------------------------------");
		//******************************************Choices for user what they want*****************************************
		int ch;
		char cond;
		do
		{
		       System.out.println("Hello  "+username+", Welcome to Our Online Apllcation.\n Here are Some Services which our bank is provide to you");
			System.out.println("1.Create Account");
			System.out.println("2.Add Account");
			System.out.println("3.CheckBalance");
			System.out.println("4.Withdraw Ammount");
			System.out.println("5.Deposit Ammount");
			System.out.println("6.Transfer Money");
			//System.out.println("6.Delete account");
			System.out.println("--------------------------------------------------------------");
			System.out.println("Enter what you want:- ");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				CreateAccount.createAcc();                         //Create account method from CreateAccount class
				break;
			case 2:
				CreateAccount.addCustomer();
				break;
			case 3:
				DepositWithdraw.checkBalance();                   //check balance from DepositeWithdraw class
				break;
			case 4:
				DepositWithdraw.withdrawAmmount();                 //withdraw amount from DepositeWithdraw class
				break;
			case 5:
				DepositWithdraw.depositAmmount();                   //deposit amount from DepositeWithdraw class
				break;
			case 6:
				DepositWithdraw.transferMoney();                    //transfer money from DepositeWithdraw class
				break;
			default:
				System.out.println("Sorry ! You have enterded an wrong option....please check");
				break;
			}
			System.out.println("--------------------------------------------------------------");
			System.out.println("Click 'y' if you want to continue, and 'n' if you want to Log Out ");
			System.out.println("Do you Want to continue? y/n:- ");
			cond=sc.next().charAt(0);
		}
		while(cond=='y' || cond=='Y');
		if(cond== 'n' ||cond== 'N')
		{
			System.out.println("You Have Been Logged Out through session. \n Thank you!");
		}
	}
	//***********************************************************Pin validation*********************************************************************
	static void pin() 
	{
	
		 try
			{
				//code that may throws exception
	    	   System.out.print("Enter New Password:");
	           passcode = sc.nextInt();
	           for(int i=1;i<=1000;i++)
	           {
	           if(passcode<=9999 && passcode>=1000)
				{
				}
	           else
	           {
	        	   System.out.println("Pin must be four digit");
	        	   pin();
	           }
	           break;
	           }
			}
			catch(InputMismatchException e)
			{
				//handle the Arithmetic Exception
				System.out.println("Error use numbers not alphabets or any type of character");
			}		
	}	
	//***********************************************************Main Method*********************************************************************
	public static void main(String[] args) throws Exception 
	{
		choice();
	}

}
